// header

const header = document.getElementById("mainHeader");

window.addEventListener("scroll", () => {
  if (window.scrollY > 80) {
    header.classList.add("shrink");
  } else {
    header.classList.remove("shrink");
  }
});




$('.responsive').slick({
  dots: true,
  infinite: false,
  speed: 300,
  slidesToShow: 4,
  slidesToScroll: 4,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});


// reservation script 

document.getElementById("reservationForm").addEventListener("submit", function (e) {
  e.preventDefault();
  alert("✅ Your table has been booked successfully!");
  this.reset();
});


// contact 

document.getElementById("contactForm").addEventListener("submit", function (e) {
  e.preventDefault();
  alert("Message sent successfully!");
  this.reset();
});


// gallery fetch 

const recipesRow = document.getElementById("recipesRow");

// fetch meals by letter (e.g., 'a' returns many recipes)
fetch("https://www.themealdb.com/api/json/v1/1/search.php?f=a")
  .then(res => res.json())
  .then(data => {
    const meals = data.meals || [];
    meals.forEach((meal, index) => {
      // create column
      const col = document.createElement("div");
      col.className = "col-lg-4 col-md-6";

      // create card
      const card = document.createElement("div");
      card.className = "recipe-card card border-0";

      // image
      const img = document.createElement("img");
      img.src = meal.strMealThumb;
      img.className = "card-img-top";
      img.alt = meal.strMeal;

      // card body
      const body = document.createElement("div");
      body.className = "card-body";

      const title = document.createElement("h5");
      title.className = "recipe-title";
      title.textContent = meal.strMeal;

      body.appendChild(title);
      card.appendChild(img);
      card.appendChild(body);
      col.appendChild(card);
      recipesRow.appendChild(col);

      // animation delay
      setTimeout(() => {
        card.classList.add("show");
      }, 100 * index);
    });
  })
  .catch(err => {
    console.error(err);
    recipesRow.innerHTML = "<p class='text-center'>Failed to load recipes.</p>";
  });



// menu 


const tabs = document.querySelectorAll(".tab-btn");
const groups = document.querySelectorAll(".menu-group");

tabs.forEach(tab => {
  tab.addEventListener("click", () => {

    tabs.forEach(t => t.classList.remove("active"));
    tab.classList.add("active");

    groups.forEach(group => group.classList.remove("active"));

    document.getElementById(tab.dataset.target).classList.add("active");
  });
});


const sections = document.querySelectorAll(".menu-section");
const links = document.querySelectorAll(".menu-tabs .nav-link");

window.addEventListener("scroll", () => {
  let current = "";

  sections.forEach(section => {
    if (scrollY >= section.offsetTop - 150) {
      current = section.getAttribute("id");
    }
  });

  links.forEach(link => {
    link.classList.remove("active");
    if (link.getAttribute("href") === "#" + current) {
      link.classList.add("active");
    }
  });
});


AOS.init({
  duration: 900,
  once: true
});