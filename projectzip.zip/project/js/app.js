const tabs = document.querySelectorAll(".tab-btn");
const groups = document.querySelectorAll(".menu-group");

tabs.forEach(tab => {
  tab.addEventListener("click", () => {

    tabs.forEach(t => t.classList.remove("active"));
    tab.classList.add("active");

    groups.forEach(group => group.classList.remove("active"));

    document.getElementById(tab.dataset.target).classList.add("active");
  });
});


const sections = document.querySelectorAll(".menu-section");
const links = document.querySelectorAll(".menu-tabs .nav-link");

window.addEventListener("scroll", () => {
  let current = "";

  sections.forEach(section => {
    if (scrollY >= section.offsetTop - 150) {
      current = section.getAttribute("id");
    }
  });

  links.forEach(link => {
    link.classList.remove("active");
    if (link.getAttribute("href") === "#" + current) {
      link.classList.add("active");
    }
  });
});
